-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12 Agu 2019 pada 00.10
-- Versi Server: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugasy`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa`
--

CREATE TABLE `diagnosa` (
  `kode_diagnosa` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa`
--

INSERT INTO `diagnosa` (`kode_diagnosa`, `email`, `date_created`) VALUES
(3, 'galihrexyhakiki@gmail.com', 1565017610),
(4, 'galihrexyhakiki@gmail.com', 1565132210),
(5, 'galihrexyhakiki@gmail.com', 1565132230),
(6, 'galihrexyhakiki@gmail.com', 1565133594),
(7, 'galihrexyhakiki@gmail.com', 1565133702),
(8, 'galihrexyhakiki@gmail.com', 1565143930),
(9, 'galihrexyhakiki@gmail.com', 1565143959),
(10, 'galihrexyhakiki@gmail.com', 1565143981),
(11, 'galihrexyhakiki@gmail.com', 1565144179),
(12, 'galihrexyhakiki@gmail.com', 1565158729),
(13, 'galihrexyhakiki@gmail.com', 1565187152),
(14, 'galihrexyhakiki@gmail.com', 1565528701),
(15, 'doddy@gmail.com', 1565529574),
(16, 'doddy@gmail.com', 1565530187),
(17, 'hi@gmail.com', 1565530709);

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa_detail`
--

CREATE TABLE `diagnosa_detail` (
  `kode_diagnosa_detail` int(11) NOT NULL,
  `kode_diagnosa` int(11) NOT NULL,
  `kode_gejala` varchar(50) NOT NULL DEFAULT 'G0_',
  `kode_penyakit` varchar(11) NOT NULL DEFAULT 'P0_',
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `diagnosa_detail`
--

INSERT INTO `diagnosa_detail` (`kode_diagnosa_detail`, `kode_diagnosa`, `kode_gejala`, `kode_penyakit`, `date_created`) VALUES
(15, 7, 'K1 & GJL/005', 'PYKT/002', 1565133702),
(16, 8, 'GJL/001', 'PYKT/001', 1565143930),
(17, 8, 'GJL/002', 'PYKT/001', 1565143930),
(18, 8, 'K1 & PYKT/001', 'PYKT/004', 1565143930),
(19, 10, 'K1 & GJL/005', 'PYKT/002', 1565143981),
(20, 11, 'GJL/001', 'PYKT/001', 1565144179),
(21, 11, 'GJL/002', 'PYKT/001', 1565144179),
(22, 12, 'K1 & GJL/006', 'PYKT/003', 1565158729),
(23, 13, 'K1 & GJL/006', 'PYKT/003', 1565187152),
(24, 14, 'GJL/001', 'PYKT/001', 1565528701),
(25, 14, 'GJL/008', 'PYKT/004', 1565528702),
(26, 14, 'GJL/012', 'PYKT/006', 1565528702),
(27, 14, 'GJL/030', 'PYKT/016', 1565528702),
(28, 15, 'GJL/001', 'PYKT/001', 1565529574),
(29, 15, 'GJL/002', 'PYKT/001', 1565529574),
(30, 15, 'GJL/030', 'PYKT/016', 1565529574),
(31, 16, 'GJL/005', 'PYKT/002', 1565530187),
(32, 16, 'GJL/025', 'PYKT/013', 1565530187),
(33, 16, 'PYKT/013 & GJL/025', 'PYKT/015', 1565530187),
(34, 17, 'K1 & GJL/005', 'PYKT/002', 1565530709),
(35, 17, 'GJL/030', 'PYKT/016', 1565530709);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `kode_gejala` varchar(50) NOT NULL DEFAULT 'G0_',
  `kode_penyakit` varchar(11) NOT NULL DEFAULT 'P0_',
  `nama_gejala` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`kode_gejala`, `kode_penyakit`, `nama_gejala`) VALUES
('GJL/001', 'PYKT/2019/1', 'Anak tidak bisa minum atau menyusu'),
('GJL/002', 'PYKT/2019/1', 'Anak memuntahkan makanan yang dimakan'),
('GJL/003', 'PYKT/2019/1', 'Anak menderita kejang'),
('GJL/004', 'PYKT/2019/1', 'Anak tampak letargis atau tidak sadar'),
('GJL/005', 'PYKT/2019/2', 'Nafas normal'),
('GJL/006', 'PYKT/2019/3', 'Nafas cepat'),
('GJL/007', 'PYKT/2019/1', 'Tarikan dinding dada kedalam'),
('GJL/008', 'PYKT/2019/1', 'Stridor'),
('GJL/009', 'PYKT/2019/1', 'Berak air atau lembek'),
('GJL/010', 'PYKT/2019/1', 'Mata cekung'),
('GJL/011', 'PYKT/2019/1', 'Cubitan kulit perut kembali lambat'),
('GJL/012', 'PYKT/2019/1', 'Gelisah, rewel/mudah marah'),
('GJL/013', 'PYKT/2019/1', 'Haus, minum dengan lahap'),
('GJL/014', 'PYKT/2019/1', 'Cubitan kulit perut sangat lambat'),
('GJL/015', 'PYKT/2019/1', 'Anak tampak letargis atau tidak sadar'),
('GJL/016', 'PYKT/2019/1', 'Tidak bisa minum atau malas minum'),
('GJL/017', 'PYKT/2019/1', 'Diare 14 hari atau lebih'),
('GJL/018', 'PYKT/2019/1', 'Ada darah dalam tinja'),
('GJL/019', 'PYKT/2019/1', 'Suhu badan melebihi 37.5º C'),
('GJL/020', 'PYKT/2019/1', 'Kaku kuduk (anak tidak bisa menunduk hingga dagu mencapai dada)'),
('GJL/021', 'PYKT/2019/1', 'Ruam kemerahan di kulit'),
('GJL/022', 'PYKT/2019/1', 'batuk pilek atau mata merah'),
('GJL/023', 'PYKT/2019/1', 'Luka di mulut yang dalam atau luas'),
('GJL/024', 'PYKT/2019/1', 'Kekeruhan pada kornea mata'),
('GJL/025', 'PYKT/2019/1', 'Luka di mulut'),
('GJL/026', 'PYKT/2019/1', 'Mata bernanah'),
('GJL/027', 'PYKT/2019/1', 'Demam 2 - 7 hari'),
('GJL/028', 'PYKT/2019/1', 'Demam mendadak tinggi dan terus menerus'),
('GJL/029', 'PYKT/2019/1', 'Nyeri di ulu hati'),
('GJL/030', 'PYKT/2019/1', 'bintik bintik merah'),
('GJL/031', 'PYKT/2019/1', 'Muntah bercampur darah / seperti kopi'),
('GJL/032', 'PYKT/2019/1', 'Tinja berwarna hitam'),
('GJL/033', 'PYKT/2019/1', 'Perdarahan dihidung dan gusi'),
('GJL/034', 'PYKT/2019/1', 'Syok dan gelisah'),
('GJL/035', 'PYKT/2019/1', 'Infeksi'),
('GJL/036', 'PYKT/2019/1', 'Pilek');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_return`
--

CREATE TABLE `gejala_return` (
  `id_gejala_return` int(11) NOT NULL,
  `kode_penyakit` varchar(11) NOT NULL,
  `kode_gejala_return` varchar(50) NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala_return`
--

INSERT INTO `gejala_return` (`id_gejala_return`, `kode_penyakit`, `kode_gejala_return`, `keterangan`) VALUES
(1, 'PYKT/001', 'GJL/001', 'Anak tidak bisa minum dan menyusu'),
(2, 'PYKT/001', 'GJL/002', 'Anak Memuntahkan makanan yang dimakan'),
(3, 'PYKT/001', 'GJL/003', 'Anak menderita kejang'),
(4, 'PYKT/001', 'GJL/004', 'Anak tampak letargis dan tidak sabar'),
(5, 'PYKT/002', 'K1 & GJL/005', 'Ada keluhan Batuk dan nafas normal'),
(6, 'PYKT/003', 'K1 & GJL/006', 'Ada keluhan batuk dan nafas cepat'),
(7, 'PYKT/004', 'K1 & PYKT/001', 'Ada keluhan Batuk dan terdapat tanda bahaya umum'),
(8, 'PYKT/004', 'GJL/007', 'Tarikan dinding dada ke dalam'),
(9, 'PYKT/004', 'GJL/008', 'Stridor'),
(10, 'PYKT/005', 'K2 & GJL/009', 'Ada keluhan Diare dan Berak cair atau lembek'),
(11, 'PYKT/006', 'P5 & GJL/010 & GJL/011', 'Terkena penyakit diare, mata cekung dan cubitan kulit perut kembali'),
(12, 'PYKT/006', 'GJL/012', 'Gelisah, Rewel/Mudah marah'),
(13, 'PYKT/006', 'GJL/013', 'Haus, minum dengan lahap '),
(14, 'PYKT/007', 'P5 & GJL/010 & GJL/014', 'Terkena diare, Mata cekung dan Cubitan kulit perut sangat lambat'),
(15, 'PYKT/007', 'GJL/015', 'Anak tampak letargis atau tidak sadar '),
(16, 'PYKT/007', 'GJL/016', 'Tidak bisa minum atau malas minum '),
(17, 'PYKT/008', 'PYKT/005 & GJL/017', 'Terkena Diare 14 hari atau lebih '),
(18, 'PYKT/009', 'PYKT/008 & PYKT/006', 'Terkena Diare Persisten dan Diare Dehidrasi Ringan'),
(19, 'PYKT/009', 'PYKT/007', 'Terkena Diare Dehidrasi Berat'),
(20, 'PYKT/010', 'PYKT/005 & GJL/018', 'Terkena Diare dan Ada darah dalam tinja '),
(21, 'PYKT/011', 'K3 & GJL/019', 'Terkena Demam dan Suhu badan melebihi 37.5º C '),
(22, 'PYKT/012', 'PYKT/001 & PYKT/011', 'Terdapat Tanda Bahaya Umum dan Demam '),
(23, 'PYKT/012', 'GJL/020', 'Kaku Kuduk atau anak tidak bisa menunduk hingga dagu mencapai dada'),
(24, 'PYKT/013', 'PYKT/011 & GJL/021 & GJL/022', 'Terkena Demam, Ruam kemerahan di kulit dan batuk pilek atau mata merah '),
(25, 'PYKT/013', 'GJL/025', 'Terdapat Luka di mulut '),
(26, 'PYKT/014', 'PYKT/013 & PYKT/001 & GJL/023', 'Terkena Campak, tanda bahaya umum dan Luka di mulut yang dalam atau luas'),
(27, 'PYKT/014', 'GJL/024', 'Kekeruhan pada kornea mata'),
(28, 'PYKT/015', 'PYKT/013 & GJL/025', 'Terkena Campak dan Terdapat Luka di mulut '),
(29, 'PYKT/015', 'GJL/026', 'Mata bernanah '),
(30, 'PYKT/016', 'PYKT/011 & GJL/027 & GJL/028 & GJL/029', 'Terkea Demam 2 - 7 hari, demam mendadak tinggi secara terus menerus dan Nyeri di ulu hati '),
(31, 'PYKT/016', 'GJL/030', 'Bintik bintik merah'),
(32, 'PYKT/017', 'PYKT/011 & GJL/027 & GJL/028 & GJL/031', 'Terkena Demam 2 - 7 hari, Demam mendadak tinggi secara terus menerus dan Muntah bercampur darah / seperti kopi '),
(33, 'PYKT/017', 'GJL/032', 'Tinja berwarna hitam '),
(34, 'PYKT/017', 'GJL/033', 'Perdarahan dihidung dan gusi '),
(35, 'PYKT/017', 'GJL/034', 'Syok dan gelisah '),
(36, 'PYKT/018', 'PYKT/011 & GJL/035', 'Terkena Demam dan Infeksi '),
(37, 'PYKT/018', 'GJL/036', 'Pilek ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `keluhan`
--

CREATE TABLE `keluhan` (
  `kode_keluhan` varchar(11) NOT NULL,
  `nama_keluhan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `keluhan`
--

INSERT INTO `keluhan` (`kode_keluhan`, `nama_keluhan`) VALUES
('K1', 'Batuk'),
('K2', 'Diare'),
('K3', 'Demam');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyakit`
--

CREATE TABLE `penyakit` (
  `kode_penyakit` varchar(11) NOT NULL DEFAULT 'P0_',
  `nama` varchar(128) NOT NULL,
  `gambar` varchar(128) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `referensi` varchar(255) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penyakit`
--

INSERT INTO `penyakit` (`kode_penyakit`, `nama`, `gambar`, `keterangan`, `referensi`, `date_created`) VALUES
('PYKT/001', 'Tanda Bahaya Umum', 'tandabahayaumum.jpg', 'Tanda Bahaya umun yang menjangkit anak usia 5 tahun', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1563961038),
('PYKT/002', 'Batuk', 'batuk.jpg', 'Batuk disebabkan infeksi saluran pernapasan akibat virus, asap rokok, debu, atau zat kimia lain. Selain itu, ada juga batuk yang disebabkan refluks asam lambung, sinusitis, atau bahkan karena anak Anda alergi.', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1563961038),
('PYKT/003', 'Pneumonia', 'pneumonia.jpg', 'Infeksi yang menimbulkan peradangan pada kantung udara di salah satu atau kedua paru-paru, yang dapat berisi cairan.', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1556804958),
('PYKT/004', 'Pneumonia Berat', 'pneumoniaberat.jpg', 'Infeksi yang menimbulkan peradangan pada kantung udara di salah satu atau kedua paru-paru, yang dapat berisi cairan.', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1556804958),
('PYKT/005', 'Diare', 'diare.jpg', 'Diare merupakan sebuah kondisi ketika pengidapnya melakukan buang air besar (BAB) lebih sering dari biasanya. Penyakit ini biasanya berlangsung selama beberapa hari dan dalam kasus tertentu bisa berlangsung hingga berminggu-minggu.\r\n\r\n', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/006', 'Diare Dehidrasi Ringan', 'diare_dehidrasi_ringan.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1556804958),
('PYKT/007', 'Diare Dehidrasi Berat', 'diare_dehidrasi_berat.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/008', 'Diare Persisten', 'diare_persisten.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/009', 'Diare Persisten Berat', 'diare_persisten_berat.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/010', 'Disentri', 'disentri.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/011', 'Demam', 'demam.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/012', 'Demam dengan Tanda Bahaya Umum', 'demam_dengan_tanda_bahaya_umum.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/013', 'Campak', 'campak.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/014', 'Campak dengan Komplikasi Berat', 'campak_dengan_komplikasi_berat.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/015', 'Campak dengan Komplikasi', 'campak_dengan_komplikasi.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/016', 'Demam mungkin DBD', 'demam_mungkin_dbd.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/017', 'DBD', 'dbd.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677),
('PYKT/018', 'Demam bukan DBD', 'demam_bukan_dbd.jpg', '-', 'Bagus Fery Yanto, Indah Werdiningsih, Endah Purwanti  Journal of Information Systems Engineering and Business Intelligence,  2017,  3 (1), 61-67', 1565247677);

-- --------------------------------------------------------

--
-- Struktur dari tabel `request`
--

CREATE TABLE `request` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `solusi`
--

CREATE TABLE `solusi` (
  `kode_solusi` varchar(11) NOT NULL DEFAULT 'S0_',
  `kode_penyakit` varchar(11) NOT NULL DEFAULT 'P0_',
  `nama_solusi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `solusi`
--

INSERT INTO `solusi` (`kode_solusi`, `kode_penyakit`, `nama_solusi`) VALUES
('SLS/001', 'PYKT/002', 'Anak harus istirahat cukup'),
('SLS/002', 'PYKT/002', 'Minum obat batuk khusus anak'),
('SLS/003', 'PYKT/002', 'Berikan anak cairan yang cukup'),
('SLS/004', 'PYKT/002', 'Hindari makanan atau minuman penyebab batuk'),
('SLS/005', 'PYKT/002', 'Jauhkan anak dari pemicu alergi'),
('SLS/006', 'PYKT/002', 'Pilih posisi tidur yang paling nyaman'),
('SLS/007', 'PYKT/001', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/008', 'PYKT/003', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/009', 'PYKT/004', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/010', 'PYKT/005', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/011', 'PYKT/006', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/012', 'PYKT/007', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/013', 'PYKT/008', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/014', 'PYKT/009', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/015', 'PYKT/010', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/016', 'PYKT/011', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/017', 'PYKT/012', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/018', 'PYKT/013', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/019', 'PYKT/014', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/020', 'PYKT/015', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/021', 'PYKT/016', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/022', 'PYKT/017', 'Bawa ke Puskesmas atau Rumah Sakit'),
('SLS/023', 'PYKT/018', 'Bawa ke Puskesmas atau Rumah Sakit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `image`, `email`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(1, 'Galih Rexy Hakiki', 'default.jpg', 'galihrexyhakiki@gmail.com', '$2y$10$ZOUOwQ430v/GqIv/hmaMAelhulvaQCLQUijn5L8XHesYM0EVVt8tG', 3, 1, 1556804958),
(3, 'doddy', 'default.jpg', 'doddy@gmail.com', '$2y$10$ZOUOwQ430v/GqIv/hmaMAelhulvaQCLQUijn5L8XHesYM0EVVt8tG', 2, 1, 1556804958),
(4, 'hilda', 'default.jpg', 'hi@gmail.com', '$2y$10$ZOUOwQ430v/GqIv/hmaMAelhulvaQCLQUijn5L8XHesYM0EVVt8tG', 1, 1, 1556804958),
(5, 'Basuki', 'default.jpg', 'basuki@gmail.com', '$2y$10$1fp8qSeZ67GnGTzCwSuNWehVxUuGOPhN7IpcG0ZtQpxBuspZ7/EHq', 3, 1, 1565244657);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member'),
(3, 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diagnosa`
--
ALTER TABLE `diagnosa`
  ADD PRIMARY KEY (`kode_diagnosa`);

--
-- Indexes for table `diagnosa_detail`
--
ALTER TABLE `diagnosa_detail`
  ADD PRIMARY KEY (`kode_diagnosa_detail`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`kode_gejala`);

--
-- Indexes for table `gejala_return`
--
ALTER TABLE `gejala_return`
  ADD PRIMARY KEY (`id_gejala_return`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`kode_penyakit`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`kode_solusi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diagnosa`
--
ALTER TABLE `diagnosa`
  MODIFY `kode_diagnosa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `diagnosa_detail`
--
ALTER TABLE `diagnosa_detail`
  MODIFY `kode_diagnosa_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `gejala_return`
--
ALTER TABLE `gejala_return`
  MODIFY `id_gejala_return` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
