<div class="panel-header panel-header-sm">
</div>

<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <div class="places-buttons">
            <div class="row">
              <div class="col-md-6 ml-auto mr-auto text-center">
                <h4 class="card-title">
                  Diagnosa diri anda
                  <p class="category">Centang gejala yang terjadi pada diri anda dengan tepat dan tidak tergesa - gesa.</p>
                </h4>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-8 ml-auto mr-auto">
                <div class="row">
                  <table class="table">
                    <form action="<?= base_url('user/diagnosa_proses'); ?>" method="post">
                      <tbody>
                        <?php
                        $i = 0;
                        foreach ($gejala as $row) :
                          ?>
                          <tr>
                            <td>
                              <div class="form-check">
                                <label class="form-check-label">
                                  <input class="form-check-input" name="gejala[]" type="checkbox" value="<?= $row['kode_gejala']; ?>">
                                  <span class="form-check-sign"></span>
                                </label>
                              </div>
                            </td>
                            <td class="text-left"><?= $row['nama_gejala']; ?></td>
                          </tr>
                        <?php endforeach; ?>
                      </tbody>

                  </table>

                  <div class="col-lg-8 ml-auto mr-auto">
                    <div class="row">
                      <div class="col-md-4"></div>
                      <div class="col-md-4">
                        <div class="card-footer ">
                          <div class="stats">
                            <button type="submit" class="btn btn-primary btn-sm btn-round">Lanjutkan</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>