<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Selamat Datang</h2>
          <?= $this->session->flashdata('message'); ?>
          <p class="category">Penting untuk mengenali gejala awal penyakit agar tidak terlambat dalam menanganinya.</p>
        </div>
      </div>
      

      <div class="content">
        <div class="row">
<?php foreach ($penyakit as $row) : ?>
          <div class="col-lg-4 col-md-6">
            <div class="card card-chart">
              <div class="card-header">
                <h5 class="card-category"><?= $row['kode_penyakit']; ?></h5>
                <h4 class="card-title"><?= $row['nama']; ?></h4>
              </div>
              <div class="card-body">
                <img src="<?= base_url('assets/asset/img/' . $row['gambar']); ?>">
                <br><br>
                <p class="text-left"><?= $row['keterangan']; ?></p>
              </div>
                <div class="card-footer">
                <div class="stats">
                  <i class="now-ui-icons ui-2_time-alarm"></i> <?= date('d F Y', $row['date_created']); ?>
                </div>
              </div>
            </div>
          </div>
<?php endforeach; ?>


        </div>
      </div>
