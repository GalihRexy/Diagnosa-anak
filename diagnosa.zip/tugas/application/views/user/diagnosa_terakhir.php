<div class="panel-header">
  <div class="header text-center">
    <h2 class="title">Data Diagnosa Terakhir</h2>
    <p class="category">Hasil dari aplikasi ini berdasarkan gejala awal suatu penyakit. Untuk memastikannya anda bisa periksakan diri anda Dokter.</p>
  </div>
</div>


<div class="content">
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title text-center"> Hasil Diagnosa </h4>
          <hr>
        </div>
        <?php if (null == $diagnosa_terakhir) { ?>
          <div class="card-body text-center text-danger">
            <p>Silahkan lakukan diagnosa terlebih dahulu!</p>
          </div>
        <?php } ?>

        <?php for ($i = 0; $i < count($jumlah); $i++) : ?>
          <?php $data_penyakit = $this->User_model->cek_penyakit2($i); ?>
          <?php if (null !== ($data_penyakit)) : ?>
            <div class="card-body">
              <div class="table-responsive">
                <p>Anda terkena gejala untuk penyakit: </p>
                <?php $nama_penyakit = $this->User_model->nama_penyakit($data_penyakit['kode_penyakit']); ?>
                <h5><?= $nama_penyakit['nama']; ?></h5>
                <p>Gejala:</p>
                <ul>
                  <?php $gejala = $this->User_model->gejala($data_penyakit['kode_penyakit']); ?>
                  <?php for ($j = 0; $j < count($gejala); $j++) { ?>
                    <?php $data = $this->User_model->ambil_gejala($data_penyakit['kode_penyakit'], $j); ?>
                    <li><?= $data['keterangan']; ?></li>
                  <?php } ?>
                </ul>
                <p>Solusi:</p>
                <ul>
                  <?php $solusi = $this->User_model->solusi($data_penyakit['kode_penyakit']); ?>
                  <?php foreach ($solusi as $row) : ?>
                    <li><?= $row['nama_solusi']; ?></li>
                  <?php endforeach; ?>

                </ul>
                <?php $referensi = $this->User_model->ambil_referensi($data_penyakit['kode_penyakit']); ?>
                <i>Referensi: <?= $referensi['referensi']; ?></i>
                <hr>
              </div>
            </div>
          <?php endif; ?>
        <?php endfor; ?>


      </div>
    </div>
  </div>
</div>