<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal text-center">
          Gareki Diagnozer
        </a>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <li class="<?php if (isset($sidebar_dashboard)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/'); ?>">
              <i class="now-ui-icons business_bank"></i>
              <p>Home</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_profil)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/profil'); ?>">
              <i class="now-ui-icons users_single-02"></i>
              <p>admin Profile</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_diagnosa)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/diagnosa'); ?>">
              <i class="now-ui-icons education_atom"></i>
              <p>Diagnosa</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_diagnosa_terakhir)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/diagnosa_terakhir'); ?>">
              <i class="now-ui-icons files_paper"></i>
              <p>Data Diagnosa Terakhir</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_datadiagnosa)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/data_diagnosa'); ?>">
              <i class="now-ui-icons files_single-copy-04"></i>
              <p>Data Diagnosa</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_daftar_user)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/daftar_user'); ?>">
              <i class="now-ui-icons education_agenda-bookmark"></i>
              <p>Daftar User</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_request)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/request'); ?>">
              <i class="now-ui-icons business_bulb-63"></i>
              <p>Daftar Permintaan</p>
            </a>
          </li>
          <!-- <li class="<?php if (isset($sidebar_tambahdatadiagnosa)) {
                            echo 'active';
                          } ?>">
            <a href="<?= base_url('admin/tambah_data_penyakit'); ?>">
              <i class="now-ui-icons ui-1_simple-add"></i>
              <p>Tambah Data Diagnosa</p>
            </a>
          </li> -->
          <li class="<?php if (isset($sidebar_bantuan)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('admin/bantuan') ?>">
              <i class="now-ui-icons travel_info"></i>
              <p>Bantuan</p>
            </a>
          </li>
        </ul>
      </div>
    </div>