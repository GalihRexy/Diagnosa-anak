<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal text-center">
          Gareki Diagnozer
        </a>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <li class="<?php if (isset($sidebar_dashboard)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('user/'); ?>">
              <i class="now-ui-icons business_bank"></i>
              <p>Home</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_profil)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('user/profil'); ?>">
              <i class="now-ui-icons users_single-02"></i>
              <p>User Profile</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_diagnosa)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('user/diagnosa'); ?>">
              <i class="now-ui-icons education_atom"></i>
              <p>Diagnosa</p>
            </a>
          </li>
          <li class="<?php if (isset($sidebar_diagnosa_terakhir)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('user/diagnosa_terakhir'); ?>">
              <i class="now-ui-icons files_paper"></i>
              <p>Data Diagnosa Terakhir</p>
            </a>
          </li>
          <!-- <li class="<?php if (isset($sidebar_datadiagnosa)) {
                            echo 'active';
                          } ?>">
            <a href="<?= base_url('user/data_diagnosa'); ?>">
              <i class="now-ui-icons files_single-copy-04"></i>
              <p>Data Diagnosa</p>
            </a>
          </li> -->
          <li class="<?php if (isset($sidebar_bantuan)) {
                        echo 'active';
                      } ?>">
            <a href="<?= base_url('user/bantuan'); ?>">
              <i class="now-ui-icons travel_info"></i>
              <p>Bantuan</p>
            </a>
          </li>
          <li class="active-pro">
            <a href="<?= base_url('user/upgrade'); ?>" onclick="return confirm('Anda akan upgrade akun ke member?')">
              <i class="now-ui-icons objects_spaceship"></i>
              <p>Upgrade to Member</p>
            </a>
          </li>
        </ul>
      </div>
    </div>