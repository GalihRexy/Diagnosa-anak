<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Daftar User</h2>
        </div>
      </div>

<div class="content">
        <div class="row">
          <div class="col-lg-12 ml-auto mr-auto">
            <div class="card">
              <?php if (null == $user) { ?>
              <div class="card-header">
                <h4 class="card-title text-center"> Daftar Permintaan User </h4>
                <hr>
              </div>
                <div class="card-body text-center text-danger">
                  <p>Belum ada request</p>
                </div>
              <?php } ?>

              <?php if (!null == $user) { ?>
              <div class="card-header">
                <h4 class="card-title text-center"> Daftar Permintaan User </h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="card-title">
                      <tr>
                        <th class="text-left">
                          Foto Profil
                        </th>
                        <th class="text-left">
                          Nama
                        </th>
                        <th class="text-left">
                          Email
                        </th>
                        <th class="text-center">
                          Role
                        </th>
                        <th class="text-center">
                          Action
                        </th>
                      </tr>
                  </thead>
                    <tbody>
                    <?php foreach ($user as $row) : ?>
                      <tr>
                        <td class="text-center">
                          <div style="width: 70px;">
                            <img src="<?= base_url('assets/asset/img/').$row['image']; ?>" class="img-thubnail">
                          </div>
                        </td>
                        <td class="text-left">
                          <?= $row['name'];  ?>
                        </td>
                        <td class="text-left">
                          <?= $row['email']; ?>
                        </td>
                        <td class="text-center">
                          <?= $row['role_id']; ?>
                        </td class="text-left">
                        <td class="text-center">
                          <a href="<?= base_url('admin/approve?id='); echo $row['id']; ?>" class="btn btn-info btn-sm btn-round" onclick="return confirm('Upgrade akun user?')">Approve</a>
                          <a href="<?= base_url(); echo $row['id']; ?>" class="btn btn-danger btn-sm btn-round" onclick="return confirm('Tolak permintaan?')">Tolak</a>
                        </td>
                      </tr>
                  <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>