<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Menu Bantuan</h2>
          <p class="category">Ikuti langkah-langkah dibawah ini untuk menggunakan sistem pakar ini.</p>
        </div>
      </div>


<div class="content">
        <div class="row">
        	<div class="col-md-2"></div>
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Petunjuk Penggunaan </h4>
                <hr>
              </div>
              <div class="card-body">
              	<h6>Melihat Daftar Penyakit yang Dapat didiagnosa</h6>
              	<ol>
              		<li>Pilih menu Home untuk melihat daftar penyakit yang dapat didiagnosa oleh aplikasi ini.</li>
              	</ol>
              	<h6>Melihat profil</h6>
              	<ol>
              		<li>Pilih menu User Profil untuk melihat data diri anda</li>
              	</ol>
              	<h6>Melakukan Diagnosa</h6>
              	<ol>
              		<li>Pilih menu Diagnosa</li>
              		<li>Centang gejala yang anda rasakan</li>
              		<li>jika telah selesai pilih lanjutkan</li>
              	</ol>
              	<h6>Melihat Hasil Diagnosa</h6>
              	<ol>
              		<li>Setelah melakukan diagnosa maka anda akan langsung diarahkan ke hasil diagnosa atau bisa pilih menu Data Diagnosa Terakhir</li>
              	</ol>
              	<h6>Melihat Riwayat Hasil Diagnosa</h6>
              	<ol>
              		<li>Pilih menu Data Diagnosa, maka semua riwayat diagnosa anda akan ditampilkan</li>
              		<li>Pilih detail untuk melihat detail diagnosa</li>
              		<li>Pilih delete untuk menghapus riwayat diagnosa</li>
              	</ol>
              	<h6>Cara penggunaan aplikasi</h6>
              	<ol>
              		<li>Pilih menu Bantuan untuk melihat petunjuk penggunaan aplikasi</li>
              	</ol>
              </div>
            </div>
          </div>
        </div>
      </div>