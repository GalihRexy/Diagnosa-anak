<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Tambah Data Diagnosa</h2>
          <p class="category">Untuk pengisian kode gejala, penyakit dan solusi silahkan ikuti aturan yang ada.</p>
        </div>
      </div>

<div class="content">
        <div class="row">
        	<div class="col-md-2"></div>
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Penyakit </h4>
                <hr>
                 <?= $this->session->flashdata('message'); ?>
              </div>
                  <div class="card-body">
                    <div class="table-responsive">
                    <form class="form" action="<?= base_url('admin/tambah_data_penyakit'); ?>" method="post" enctype="multipart/form-data" >
                      <p >Kode Penyakit</p>
                      <div class="col-sm-6 col-lg-4">
	                        <div class="form-group">
	                            <input type="text" name="kode_penyakit" value="<?= $kode_penyakit; ?>"  class="form-control" disabled="">
	                        </div>
	                    </div>

                      <p>Nama Penyakit</p>
                      <div class="col-sm-6 col-lg-4">
                          <div class="form-group">
                              <input type="text" name="nama" value="<?= set_value('nama'); ?>" placeholder="Nama Penyakit" class="form-control">
                          </div>
                      </div>
                      <?= form_error('nama', '<span class="text-danger input-group pl-4">', '</span>') ?>

	                    <p>Keterangan</p>
                      <div class="col-sm-6 col-lg-8">
	                        <div class="form-group">
	                            <input type="text" name="keterangan" value="<?= set_value('keterangan'); ?>" placeholder="Keterangan" class="form-control">
	                        </div>
	                    </div>
                      <?= form_error('keterangan', '<span class="text-danger input-group pl-4">', '</span>') ?>

	                    <p>Referensi</p>
                      <div class="col-sm-6 col-lg-4">
	                        <div class="form-group">
	                            <input type="text" name="referensi" value="<?= set_value('referensi'); ?>" placeholder="Referensi" class="form-control">
	                        </div>
	                    </div>
                      <?= form_error('referensi', '<span class="text-danger input-group pl-4">', '</span>') ?>

	                    <p>Gambar</p>
                      <div class="col-sm-6 col-lg-8">
                        <div class="form-group">
                          <div class="custom-file">
								            <input type="file" name="gambar" class="custom-file-input" id="gambar">
                            <label class="custom-file-label" for="gambar">Choose file</label>
                          </div>
                        </div>
                      </div>
                       <?= form_error('gambar', '<span class="text-danger input-group pl-4">', '</span>') ?>
                        <hr>

                        <div class="col-lg-8 ml-auto mr-auto">
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="card-footer ">
                                <div class="stats">
                                  <button type="submit" class="btn btn-primary btn-sm btn-round">Lanjutkan</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </form>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>