<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Tambah Data Diagnosa</h2>
          <p class="category">Untuk pengisian kode gejala, penyakit dan solusi silahkan ikuti aturan yang ada.</p>
        </div>
      </div>

<div class="content">
        <div class="row">
        	<div class="col-md-2"></div>
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Gejala </h4>
                <hr>
                 <?= $this->session->flashdata('message'); ?>
              </div>
                  <div class="card-body">
                    <div class="table-responsive">
                    <form action="<?= base_url('admin/tambah_data_gejala') ?>" method="post">
                      <p >Kode Gejala</p>
                      <div class="col-sm-6 col-lg-4">
                          <div class="form-group">
                              <input type="text" value="<?= $kode_gejala; ?>" placeholder="Regular" class="form-control" disabled="">
                          </div>
                      </div>

                      <p >Kode Penyakit</p>
                      <div class="col-sm-6 col-lg-4">
	                        <div class="form-group">
	                            <input type="text" value="<?= $kode_penyakit; ?>" placeholder="Regular" class="form-control" disabled="">
	                        </div>
	                    </div>

	                  <p>Gejala</p>
                      <div class="col-sm-6 col-lg-8">
	                        <div class="form-group">
	                            <input type="text" name="gejala" value="" placeholder="Gejala" class="form-control">
	                        </div>
	                    </div>
                        <hr>

                        <div class="col-lg-8 ml-auto mr-auto">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="card-footer ">
                                <div class="stats">
                                  <div class="row">
                                      <button type="submit" class="btn btn-info btn-sm btn-round ">Tambah</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="card-footer ">
                                <div class="stats">
                                  <div class="row">
                                      <a href="<?= base_url('admin/tambah_data_solusi'); ?>" class="btn btn-primary btn-sm btn-round ">Lanjutkan</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </form>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>