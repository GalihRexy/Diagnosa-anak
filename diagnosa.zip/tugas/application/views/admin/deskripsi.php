<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Deskripsi</h2>
          <p class="category"></p>
        </div>
      </div>


<div class="content">
        <div class="row">
        	<div class="col-md-2"></div>
          <div class="col-md-8">
            <img src="<?= base_url('assets/img/login2.php'); ?>">
          </div>
        </div>
      </div>