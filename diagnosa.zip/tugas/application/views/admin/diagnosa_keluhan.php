<div class="panel-header panel-header-sm">
</div>

<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="places-buttons">
                        <div class="row">
                            <div class="col-md-6 ml-auto mr-auto text-center">
                                <h4 class="card-title">
                                    Diagnosa diri anda
                                    <p class="category">Centang Keluhan</p>
                                </h4>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-8 ml-auto mr-auto">
                                <table class="table">
                                    <form action="<?= base_url('admin/diagnosa_gejala'); ?>" method="post">
                                        <tbody>
                                            <?php
                                            $i = 0;
                                            foreach ($keluhan as $row) :
                                                ?>
                                                <tr>
                                                    <td>
                                                        <div class="form-check">
                                                            <label class="form-check-label">
                                                                <input class="form-check-input" name="keluhan[]" type="checkbox" value="<?= $row['kode_keluhan']; ?>">
                                                                <span class="form-check-sign"></span>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="text-left"><?= $row['nama_keluhan']; ?></td>
                                                    <td></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                </table>

                                <div class="col-lg-8 ml-auto mr-auto">
                                    <p class="text-danger text-center">*Tidak perlu dicentang jika tidak ada yang sesuai</p>
                                    <div class="row">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-4">
                                            <div class="card-footer ">
                                                <div class="stats">
                                                    <button type="submit" class="btn btn-primary btn-sm btn-round">Lanjutkan</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>