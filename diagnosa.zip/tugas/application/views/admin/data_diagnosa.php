<div class="panel-header panel-header-sm">
      </div>

<div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Riwayat Diagnosa </h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="card-title">
                      <tr>
	                      <th class="text-left">
	                        Tanggal
	                      </th>
	                      <th class="text-center">
	                        Kode Diagnosa
	                      </th>
	                      <th class="text-left">
	                       	Nama
	                      </th>
	                      <th class="text-center">
	                      	Jumlah Gejala
	                      </th>
	                      <th class="text-center">
	                      	Penyakit Terdeteksi
	                      </th>
	                      <th class="text-center">
	                      	Action
	                      </th>
                      </tr>
                	</thead>
                    <tbody>
                    <?php foreach ($diagnosa as $row) : ?>
                      <tr>
                      	<td class="text-left">
	                        <?= date('d F Y', $row['date_created']); ?>
	                      </td>
	                      <td class="text-center">
	                        <?= $row['kode_diagnosa'];  ?>
	                      </td>
	                      <td class="text-left">
	                      	<?php $nama = $this->User_model->nama_user($row['email']); ?>
	                        <?= $nama['name']; ?>
	                      </td>
	                      <td class="text-center">
	                      	<?php $jumlah_gejala = $this->User_model->jumlah_gejala($row['kode_diagnosa']); ?>
	                      	<?= count($jumlah_gejala); ?>
	                      </td class="text-left">
	                      <td class="text-center">
	                      	<?php $penyakit_terdeteksi = $this->User_model->penyakit_terdeteksi($row['kode_diagnosa']);?>
	                      	<?= $penyakit_terdeteksi; ?>
	                      </td>
	                      <td class="text-center">
	                      	<a href="<?= base_url('admin/view_diagnosa?id='); echo $row['kode_diagnosa']; ?>" class="btn btn-info btn-sm btn-round">Detail</a>
	                      	<a href="<?= base_url('admin/delete?id='); echo $row['kode_diagnosa']; ?>" class="btn btn-danger btn-sm btn-round" onclick="return confirm('Hapus diagnosa?')">Delete</a>
	                      </td>
                      </tr>
                  <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>