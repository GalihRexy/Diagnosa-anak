<div class="panel-header">
        <div class="header text-center">
          <h2 class="title">Tambah Data Diagnosa</h2>
          <p class="category">Untuk pengisian kode gejala, penyakit dan solusi silahkan ikuti aturan yang ada.</p>
        </div>
      </div>

<div class="content">
        <div class="row">
        	<div class="col-md-2"></div>
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Solusi </h4>
                <hr>
                 <?= $this->session->flashdata('message'); ?>
              </div>
                  <div class="card-body">
                    <div class="table-responsive">
                    <form action="<?= base_url('member/tambah_data_solusi') ?>" method="post">
                      <p >Kode Solusi</p>
                      <div class="col-sm-6 col-lg-4">
                          <div class="form-group">
                              <input type="text" value="<?= $kode_solusi; ?>" placeholder="Regular" class="form-control" disabled="">
                          </div>
                      </div>

                      <p >Kode Penyakit</p>
                      <div class="col-sm-6 col-lg-4">
	                        <div class="form-group">
	                            <input type="text" value="<?= $kode_penyakit; ?>" placeholder="Regular" class="form-control" disabled="">
	                        </div>
	                    </div>

	                  <p>Solusi</p>
                      <div class="col-sm-6 col-lg-8">
	                        <div class="form-group">
	                            <input type="text" name="solusi" value="" placeholder="Solusi" class="form-control">
	                        </div>
	                    </div>
                        <hr>

                        <div class="col-lg-8 ml-auto mr-auto">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="card-footer ">
                                <div class="stats">
                                  <div class="row">
                                      <button type="submit" class="btn btn-info btn-sm btn-round ">Tambah</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="card-footer ">
                                <div class="stats">
                                  <div class="row">
                                      <a href="<?= base_url('member/selesai'); ?>" class="btn btn-primary btn-sm btn-round ">Selesai</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </form>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>