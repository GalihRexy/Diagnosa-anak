<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller 
{

	public function __construct()
	{
		parent:: __construct();
		$this->load->library('form_validation');
		$this->load->model('Gejala_model');
		$this->load->model('Penyakit_model');
		$this->load->model('User_model');
		$this->load->model('Member_model');
		$this->load->model('Admin_model');
	}

	public function index()
	{
		$data['title'] = 'Home';
		$data['title_navbar'] = 'Home';
		$data['sidebar_dashboard'] = 'active';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['penyakit'] = $this->Penyakit_model->getAllPenyakit();


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/index');
		$this->load->view('templates/admin/admin_footer');
	}

	public function profil()
	{
		$data['title'] = 'My Profil';
		$data['title_navbar'] = 'My Profil';
		$data['sidebar_profil'] = 'active';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/profil');
		$this->load->view('templates/admin/admin_footer');
	}

	public function diagnosa()
	{
		$data['title'] = 'Diagnosa';
		$data['title_navbar'] = 'Diagnosa';
		$data['sidebar_diagnosa'] = 'active';
		$data['keluhan'] = $this->db->get('keluhan')->result_array();

		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/diagnosa_keluhan');
		$this->load->view('templates/admin/admin_footer');
	}

	public function diagnosa_gejala()
	{
		$data['title'] = 'Diagnosa';
		$data['title_navbar'] = 'Diagnosa';
		$data['sidebar_diagnosa'] = 'active';
		$data['gejala'] = $this->Gejala_model->getAllGejala();
		$keluhan = $this->input->post('keluhan');

		for ($i = 0; $i < count($keluhan); $i++) {
			if ($keluhan[$i] == 'K1') {
				$this->session->set_flashdata('K1', 'K1');
			} else if ($keluhan[$i] == 'K2') {
				$this->session->set_flashdata('K2', 'K2');
			} else if ($keluhan[$i] == 'K3') {
				$this->session->set_flashdata('K3', 'K3');
			}
		}

		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/diagnosa');
		$this->load->view('templates/admin/admin_footer');
	}

	public function diagnosa_proses()
	{
		$data = [
			'email' => $this->session->userdata('email'),
			'date_created' => time(),
		];

		$this->db->insert('diagnosa', $data);

		$gejala = $this->input->post('gejala');
		$k1 = $this->session->flashdata('K1');
		$k2 = $this->session->flashdata('k2');
		$k3 = $this->session->flashdata('K3');

		//Penyakit pertama
		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/001') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p1 = 'PYKT/001';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/001',
					'kode_penyakit' => 'PYKT/001',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			} else if ($gejala[$i] == 'GJL/002') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p1 = 'PYKT/001';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/002',
					'kode_penyakit' => 'PYKT/001',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			} else if ($gejala[$i] == 'GJL/003') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p1 = 'PYKT/001';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/003',
					'kode_penyakit' => 'PYKT/001',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			} else if ($gejala[$i] == 'GJL/004') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p1 = 'PYKT/001';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/004',
					'kode_penyakit' => 'PYKT/001',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit kedua
		$k1 = $this->session->flashdata('K1');

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/005') {
				if (isset($k1)) {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'K1 & GJL/005',
						'kode_penyakit' => 'PYKT/002',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit ketiga
		$k1 = $this->session->flashdata('K1');

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/006') {
				if (isset($k1)) {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'K1 & GJL/006',
						'kode_penyakit' => 'PYKT/003',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit keempat
		$k1 = $this->session->flashdata('K1');

		if (isset($k1) && isset($p1)) {
			$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
			$data = [
				'kode_diagnosa' => $diagnosa->kode_diagnosa,
				'kode_gejala' => 'K1 & PYKT/001',
				'kode_penyakit' => 'PYKT/004',
				'date_created' => time(),
			];

			$this->db->insert('diagnosa_detail', $data);
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/007') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/007',
					'kode_penyakit' => 'PYKT/004',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/008') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/008',
					'kode_penyakit' => 'PYKT/004',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit kelima
		$k2 = $this->session->flashdata('K2');

		if (isset($k2)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/009') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$p5 = 'PYKT/005';
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'K2 & GJL/009',
						'kode_penyakit' => 'PYKT/005',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit keenam
		if (isset($p5)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/010') {
					for ($j = 0; $j < count($gejala); $j++) {
						if ($gejala[$j] == 'GJL/011') {
							$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
							$p6 = 'PYKT/006';
							$data = [
								'kode_diagnosa' => $diagnosa->kode_diagnosa,
								'kode_gejala' => 'P5 & GJL/010 & GJL/011',
								'kode_penyakit' => 'PYKT/006',
								'date_created' => time(),
							];

							$this->db->insert('diagnosa_detail', $data);
						}
					}
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/012') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p6 = 'PYKT/006';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/012',
					'kode_penyakit' => 'PYKT/006',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/013') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p6 = 'PYKT/006';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/013',
					'kode_penyakit' => 'PYKT/006',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit ketujuh
		if (isset($p5)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/010') {
					for ($j = 0; $j < count($gejala); $j++) {
						if ($gejala[$j] == 'GJL/014') {
							$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

							$data = [
								'kode_diagnosa' => $diagnosa->kode_diagnosa,
								'kode_gejala' => 'P5 & GJL/010 & GJL/014',
								'kode_penyakit' => 'PYKT/007',
								'date_created' => time(),
							];

							$this->db->insert('diagnosa_detail', $data);
						}
					}
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/015') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/015',
					'kode_penyakit' => 'PYKT/007',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/016') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/016',
					'kode_penyakit' => 'PYKT/007',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit kedelapan
		if (isset($p5)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/017') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$p8 = 'PYKT/008';
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'PYKT/005 & GJL/017',
						'kode_penyakit' => 'PYKT/008',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit kesembilan
		if (isset($p8) && isset($p6)) {
			$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

			$data = [
				'kode_diagnosa' => $diagnosa->kode_diagnosa,
				'kode_gejala' => 'PYKT/008 & PYKT/006',
				'kode_penyakit' => 'PYKT/009',
				'date_created' => time(),
			];

			$this->db->insert('diagnosa_detail', $data);
		} else if (isset($p7)) {
			$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

			$data = [
				'kode_diagnosa' => $diagnosa->kode_diagnosa,
				'kode_gejala' => 'PYKT/007',
				'kode_penyakit' => 'PYKT/009',
				'date_created' => time(),
			];

			$this->db->insert('diagnosa_detail', $data);
		}

		//Penyakit kesepuluh
		if ($p5) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/018') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'PYKT/005 & GJL/018',
						'kode_penyakit' => 'PYKT/010',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit kesebelas
		if (isset($k3)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/019') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$p11 = 'PYKT/011';
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'K3 & GJL/019',
						'kode_penyakit' => 'PYKT/011',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		//Penyakit keduabelas
		if (isset($p1)) {
			if (isset($p11)) {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'PYKT/001 & PYKT/011',
					'kode_penyakit' => 'PYKT/012',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/020') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/020',
					'kode_penyakit' => 'PYKT/012',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit ketigabelas
		if (isset($p11)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/021') {
					for ($j = 0; $j < count($gejala); $j++) {
						if ($gejala[$j] == 'GJL/022') {
							$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
							$p13 = 'PYKT/013';
							$data = [
								'kode_diagnosa' => $diagnosa->kode_diagnosa,
								'kode_gejala' => 'PYKT/011 & GJL/021 & GJL/022',
								'kode_penyakit' => 'PYKT/013',
								'date_created' => time(),
							];

							$this->db->insert('diagnosa_detail', $data);
						}
					}
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/025') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p13 = 'PYKT/013';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/025',
					'kode_penyakit' => 'PYKT/013',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit keempat belas
		if ($p13 && $p1) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/023') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
					$p14 = 'PYKT/014';
					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'PYKT/013 & PYKT/001 & GJL/023',
						'kode_penyakit' => 'PYKT/014',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/024') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();
				$p14 = 'PYKT/014';
				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/024',
					'kode_penyakit' => 'PYKT/014',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit kelima belas
		if (isset($p13)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/025') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'PYKT/013 & GJL/025',
						'kode_penyakit' => 'PYKT/015',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/026') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/026',
					'kode_penyakit' => 'PYKT/015',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit ke enam belas
		if (isset($p11)) {
			for ($i = 0; $i < $gejala; $i++) {
				if ($gejala[$i] == 'GJL/027') {
					for ($j = 0; $j < count($gejala); $j++) {
						if ($gejala[$j] == 'GJL/028') {
							for ($k = 0; $k < count($gejala); $k++) {
								if ($gejala[$k] == 'GJL/029') {
									$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

									$data = [
										'kode_diagnosa' => $diagnosa->kode_diagnosa,
										'kode_gejala' => 'PYKT/011 & GJL/027 & GJL/028 & GJL/029',
										'kode_penyakit' => 'PYKT/016',
										'date_created' => time(),
									];

									$this->db->insert('diagnosa_detail', $data);
								}
							}
						}
					}
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/030') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/030',
					'kode_penyakit' => 'PYKT/016',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit ke tujuh belas
		if (isset($p11)) {
			for ($i = 0; $i < $gejala; $i++) {
				if ($gejala[$i] == 'GJL/027') {
					for ($j = 0; $j < count($gejala); $j++) {
						if ($gejala[$j] == 'GJL/028') {
							for ($k = 0; $k < count($gejala); $k++) {
								if ($gejala[$k] == 'GJL/031') {
									$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

									$data = [
										'kode_diagnosa' => $diagnosa->kode_diagnosa,
										'kode_gejala' => 'PYKT/011 & GJL/027 & GJL/028 & GJL/031',
										'kode_penyakit' => 'PYKT/017',
										'date_created' => time(),
									];

									$this->db->insert('diagnosa_detail', $data);
								}
							}
						}
					}
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/032') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/032',
					'kode_penyakit' => 'PYKT/017',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			} else if ($gejala[$i] == 'GJL/033') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/033',
					'kode_penyakit' => 'PYKT/017',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			} else if ($gejala[$i] == 'GJL/034') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/034',
					'kode_penyakit' => 'PYKT/017',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		//Penyakit ke delapan belas
		if (isset($p11)) {
			for ($i = 0; $i < count($gejala); $i++) {
				if ($gejala[$i] == 'GJL/035') {
					$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

					$data = [
						'kode_diagnosa' => $diagnosa->kode_diagnosa,
						'kode_gejala' => 'PYKT/011 & GJL/035',
						'kode_penyakit' => 'PYKT/018',
						'date_created' => time(),
					];

					$this->db->insert('diagnosa_detail', $data);
				}
			}
		}

		for ($i = 0; $i < count($gejala); $i++) {
			if ($gejala[$i] == 'GJL/036') {
				$diagnosa = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')])->last_row();

				$data = [
					'kode_diagnosa' => $diagnosa->kode_diagnosa,
					'kode_gejala' => 'GJL/036',
					'kode_penyakit' => 'PYKT/018',
					'date_created' => time(),
				];

				$this->db->insert('diagnosa_detail', $data);
			}
		}

		redirect(base_url('admin/diagnosa_terakhir'));
	}


	public function diagnosa_terakhir()
	{
		$data['title'] = 'Diagnosa Terakhir';
		$data['sidebar_diagnosa_terakhir'] = 'active';
		$data['title_navbar'] = 'Data Diagnosa Terakhir';

		$data['diagnosa_terakhir'] = $this->User_model->diagnosa_terakhir();
		$data['jumlah'] = $this->User_model->jumlah_penyakit();

		

		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/diagnosa_terakhir');
		$this->load->view('templates/admin/admin_footer');
	}


	public function data_diagnosa()
	{
		$data['title'] = 'Data Diagnosa';
		$data['sidebar_datadiagnosa'] = 'active';
		$data['title_navbar'] = 'Data Diagnosa';

		$auth = $this->session->userdata('email');
		$data['user'] = $this->User_model->DataUser();
		$data['diagnosa'] = $this->User_model->diagnosa_all();


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/data_diagnosa');
		$this->load->view('templates/admin/admin_footer');
	}

	public function view_diagnosa()
	{
		$data['title'] = 'Detail Data Diagnosa';
		$data['sidebar_datadiagnosa'] = 'active';
		$data['title_navbar'] = 'Detail Data Diagnosa';
		

		$id = $this->input->get('id');
		$data['diagnosa'] = $this->User_model->data_diagnosa($id);
		$data['jumlah'] = $this->User_model->jumlah_penyakit();


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/view_diagnosa');
		$this->load->view('templates/admin/admin_footer');
	}

	public function delete()
	{
		$id = $this->input->get('id');
		$tables = array('diagnosa', 'diagnosa_detail');
		$this->db->where('kode_diagnosa', $id);
		$this->db->delete($tables);
		redirect(base_url('admin/data_diagnosa'));
	}

	public function tambah_data_penyakit()
	{
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim', [
				'required' => 'Nama Penyakit tidak boleh kosong',
		]);
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required|trim', [
				'required' => 'Keterangan tidak boleh kosong',
		]);
		$this->form_validation->set_rules('referensi', 'Referensi', 'required|trim', [
				'required' => 'Referensi tidak boleh kosong',
		]);


		if ($this->form_validation->run() == false) {
			$data['title'] = 'Tambah Data Diagnosa';
			$data['sidebar_tambahdatadiagnosa'] = 'active';
			$data['title_navbar'] = 'Tambah Data Diagnosa';
			
			$data['kode_gejala'] = $this->Member_model->kode_gejala();
			$data['kode_penyakit'] = $this->Member_model->kode_penyakit();


			$this->load->view('templates/admin/admin_header', $data);
			$this->load->view('templates/admin/admin_sidebar');
			$this->load->view('templates/admin/admin_navbar');
			$this->load->view('admin/tambah_data_penyakit');
			$this->load->view('templates/admin/admin_footer');
		} else {
			$kode_penyakit = $this->Member_model->kode_penyakit();

			$gambar = $_FILES['gambar']['name'];
			
			
			if ($gambar = '') {
				$error = 'Tidak ada file yang di upload';
			}else{
				$config['allowed_types'] = 'gif|jpg|png|pdf';
				$config['max_width'] = '1028';
				$config['max_height'] = '768';
				$config['upload_path'] = './assets/asset/img';
				$config['overwrite'] = true;

				$this->load->library('upload', $config); 

				if (!$this->upload->do_upload('gambar')) {
					$this->session->set_flashdata('message', '
					<div class="alert alert-danger" role="alert">
	                    <div class="container">
	                        <div class="alert-icon">
	                            <i class="now-ui-icons ui-2_like"><?= $this->upload->display_error() ?></i>
	                        </div>
	                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                            <span aria-hidden="true">
	                                <i class="now-ui-icons ui-1_simple-remove"></i>
	                            </span>
	                        </button>
	                    </div>
	                </div>
					');
					redirect(base_url('admin/tambah_data_penyakit'));
				}else{
					$data = [
						'kode_penyakit' => $kode_penyakit,
						'nama' => $this->input->post('nama'),
						'gambar' => $this->upload->data('file_name'),
						'keterangan' => $this->input->post('keterangan'),
						'referensi' => $this->input->post('referensi'),
						'date_created' => time(),
					];

					$this->db->insert('penyakit', $data);
					$this->session->set_flashdata('message', '
					<div class="alert alert-success" role="alert">
	                    <div class="container">
	                        <div class="alert-icon">
	                            <i class="now-ui-icons ui-2_like"></i>
	                        </div>
	                        Berhasil menambahkan data penyakit.
	                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                            <span aria-hidden="true">
	                                <i class="now-ui-icons ui-1_simple-remove"></i>
	                            </span>
	                        </button>
	                    </div>
	                </div>
					');
					redirect(base_url('admin/tambah_data_gejala'));
					
				}

			}
		}


	}

	public function tambah_data_gejala()
	{
		$this->form_validation->set_rules('gejala', 'Gejala', 'required|trim', [
				'required' => 'Nama Penyakit tidak boleh kosong',
		]);

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Tambah Data Diagnosa';
			$data['sidebar_tambahdatadiagnosa'] = 'active';
			$data['title_navbar'] = 'Tambah Data Diagnosa';
			
			$data['kode_gejala'] = $this->Member_model->kode_gejala();
			$data['kode_penyakit'] = $this->Member_model->kode_penyakit2();


			$this->load->view('templates/admin/admin_header', $data);
			$this->load->view('templates/admin/admin_sidebar');
			$this->load->view('templates/admin/admin_navbar');
			$this->load->view('admin/tambah_data_gejala');
			$this->load->view('templates/admin/admin_footer');
		} else {
			$data = [
				'kode_gejala' => $this->Member_model->kode_gejala(),
				'kode_penyakit' => $this->Member_model->kode_penyakit2(),
				'nama_gejala' => $this->input->post('gejala'),
			];

			$this->db->insert('gejala', $data);
			$this->session->set_flashdata('message', '
					<div class="alert alert-success" role="alert">
	                    <div class="container">
	                        <div class="alert-icon">
	                            <i class="now-ui-icons ui-2_like"></i>
	                        </div>
	                        Berhasil menambahkan data gejala.
	                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                            <span aria-hidden="true">
	                                <i class="now-ui-icons ui-1_simple-remove"></i>
	                            </span>
	                        </button>
	                    </div>
	                </div>
					');
			redirect(base_url('admin/tambah_data_gejala'));
		}
	}

	public function tambah_data_solusi()
	{
		$this->form_validation->set_rules('solusi', 'Solusi', 'required|trim', [
				'required' => 'Nama Penyakit tidak boleh kosong',
		]);

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Tambah Data Diagnosa';
			$data['sidebar_tambahdatadiagnosa'] = 'active';
			$data['title_navbar'] = 'Tambah Data Diagnosa';
			
			$data['kode_solusi'] = $this->Member_model->kode_solusi();
			$data['kode_penyakit'] = $this->Member_model->kode_penyakit2();


			$this->load->view('templates/admin/admin_header', $data);
			$this->load->view('templates/admin/admin_sidebar');
			$this->load->view('templates/admin/admin_navbar');
			$this->load->view('admin/tambah_data_solusi');
			$this->load->view('templates/admin/admin_footer');
		} else {
			$data = [
				'kode_solusi' => $this->Member_model->kode_solusi(),
				'kode_penyakit' => $this->Member_model->kode_penyakit2(),
				'nama_solusi' => $this->input->post('solusi'),
			];

			$this->db->insert('solusi', $data);
			$this->session->set_flashdata('message', '
					<div class="alert alert-success" role="alert">
	                    <div class="container">
	                        <div class="alert-icon">
	                            <i class="now-ui-icons ui-2_like"></i>
	                        </div>
	                        Berhasil menambahkan data solusi.
	                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                            <span aria-hidden="true">
	                                <i class="now-ui-icons ui-1_simple-remove"></i>
	                            </span>
	                        </button>
	                    </div>
	                </div>
					');
			redirect(base_url('admin/tambah_data_solusi'));
		}

	}

	public function selesai()
	{
		// $this->session->set_flashdata('message', '
		// 			<div class="alert alert-success" role="alert">
	 //                    <div class="container">
	 //                        <div class="alert-icon">
	 //                            <i class="now-ui-icons ui-2_like"></i>
	 //                        </div>
	 //                        Berhasil menambahkan diagnosa baru.
	 //                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	 //                            <span aria-hidden="true">
	 //                                <i class="now-ui-icons ui-1_simple-remove"></i>
	 //                            </span>
	 //                        </button>
	 //                    </div>
	 //                </div>
		// 			');

		$this->session->set_flashdata('message', 'Menambahkan Diagnosa Baru.');
		redirect(base_url('admin/'));
	}

	public function daftar_user()
	{
		$data['title'] = 'Daftar User';
		$data['sidebar_daftar_user'] = 'active';
		$data['title_navbar'] = 'Daftar User';

		$data['user'] = $this->db->get('user')->result_array();
		

		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/daftar_user');
		$this->load->view('templates/admin/admin_footer');
	}

	public function bantuan()
	{
		$data['title'] = 'Bantuan';
		$data['sidebar_bantuan'] = 'active';
		$data['title_navbar'] = 'Bantuan';


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/bantuan');
		$this->load->view('templates/admin/admin_footer');
	}

	public function request()
	{
		$data['title'] = 'Daftar Permintaan';
		$data['sidebar_request'] = 'active';
		$data['title_navbar'] = 'Daftar Permintaan';

		$data['user'] = $this->Admin_model->data_request();


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/request');
		$this->load->view('templates/admin/admin_footer');
	}

	public function approve()
	{
		$id = $this->input->get('id');
		$user = $this->db->get_where('user', ['id' => $id])->row_array();

		$data = array(
			'name' => $user['name'],
			'image' => $user['image'],
			'email' => $user['email'],
			'password' =>$user['password'],
			'role_id' => 2,
			'is_active' => $user['is_active'],
			'date_created' => $user['date_created'],
		);
		$this->db->where('id', $id);
		$this->db->update('user', $data);


		$this->db->where('email', $user['email']);
		$this->db->delete('request');

		$this->session->set_flashdata('message', '
					<div class="alert alert-success" role="alert">
	                    <div class="container">
	                        <div class="alert-icon">
	                            <i class="now-ui-icons ui-2_like">Upgrade user berhasil.</i>
	                        </div>
	                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                            <span aria-hidden="true">
	                                <i class="now-ui-icons ui-1_simple-remove"></i>
	                            </span>
	                        </button>
	                    </div>
	                </div>
					');
		redirect(base_url('admin/'));
	}

	public function deskripsi()
	{
		$data['title'] = 'Daftar Permintaan';
		$data['sidebar_request'] = 'active';
		$data['title_navbar'] = 'Daftar Permintaan';

		$data['user'] = $this->Admin_model->data_request();


		$this->load->view('templates/admin/admin_header', $data);
		$this->load->view('templates/admin/admin_sidebar');
		$this->load->view('templates/admin/admin_navbar');
		$this->load->view('admin/deskripsi');
		$this->load->view('templates/admin/admin_footer');
	}
}