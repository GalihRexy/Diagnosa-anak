<?php 

class Admin_model extends CI_Model
{
	public function data_request()
	{
		$user = $this->db->get_where('request', ['status' => 0])->result_array();
		if (!null == $user) {
			for ($i=0; $i < count($user); $i++) { 
				$result[$i] = $this->db->get_where('user', ['email' => $user[$i]['email']])->row_array();
			}
			
			return $result;
		}
	}
}