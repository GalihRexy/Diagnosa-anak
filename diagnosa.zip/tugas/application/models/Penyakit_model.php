<?php 

class Penyakit_model extends CI_Model {

	public function getAllPenyakit()
	{
		return $this->db->get('penyakit')->result_array();
	}


}