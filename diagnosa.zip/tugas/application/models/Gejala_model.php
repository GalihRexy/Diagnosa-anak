<?php

class Gejala_model extends CI_Model
{

	public function getAllGejala()
	{
		$gejala = $this->db->get('gejala')->result_array();
		// shuffle($gejala);
		return $gejala;
	}
}
