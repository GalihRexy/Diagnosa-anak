<?php 

class Member_model extends CI_Model
{

	public function kode_penyakit()
	{
		$penyakit = $this->db->get('penyakit')->result_array();
		$jumlah = count($penyakit)+1;
		$kode_penyakit = 'PYKT/'.date('Y').'/'.$jumlah;
		
		return $kode_penyakit;
	}

	public function kode_penyakit2()
	{
		$penyakit = $this->db->get('penyakit')->result_array();
		$jumlah = count($penyakit);
		$kode_penyakit = 'PYKT/'.date('Y').'/'.$jumlah;
		
		return $kode_penyakit;
	}

	public function kode_gejala()
	{
		$gejala = $this->db->get('gejala')->result_array();
		$jumlah = count($gejala)+1;
		$kode_gejala = 'GJL/'.date('Y').'/'.$jumlah;
		
		return $kode_gejala;
	}

	public function kode_solusi()
	{
		$solusi = $this->db->get('solusi')->result_array();
		$jumlah = count($solusi)+1;
		$kode_solusi = 'SLS/'.date('Y').'/'.$jumlah;
		
		return $kode_solusi;
	}
}