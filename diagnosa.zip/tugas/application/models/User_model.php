<?php 

class User_model extends CI_Model
{

	public function DataUser()
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		return $auth;
	}

	public function detail_user()
	{
		$this->db->select('*');
		$this->db->from('user');
		$this->db->join('diagnosa', 'diagnosa.email = user.email');
		$query = $this->db->get();
		return $query->result();
	}

	public function jumlah_gejala($request)
	{
		$query = $this->db->get_where('diagnosa_detail', ['kode_diagnosa' => $request])->result_array();
		return $query;
	}

	public function nama_user($request)
	{
		$query = $this->db->get_where('user', ['email' => $request])->row_array();
		return $query;
	}

	public function penyakit_terdeteksi($request)
	{
		$diagnosa = $this->db->get_where('diagnosa', ['kode_diagnosa' => $request])->row_array();
		$penyakit = $this->db->get_where('penyakit')->result_array();
		for ($i=0; $i < count($penyakit); $i++) { 
		$data_penyakit[$i] = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $request, 'kode_penyakit' => $penyakit[$i]['kode_penyakit']))->row_array();
		}

		$jumlah = 0;
		if (isset($diagnosa)) {
			for ($i=0; $i < count($data_penyakit); $i++) { 
				if (isset($data_penyakit[$i])) {
					$jumlah = $jumlah + 1;
				}
			}
		}
		return $jumlah;
	}

	public function diagnosa_all()
	{
		$this->db->order_by('kode_diagnosa', 'DESC');
		$query = $this->db->get_where('diagnosa', ['email' => $this->session->userdata('email')]);
		return $query->result_array();
	}

	public function diagnosa_terakhir()
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
	 	$result = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		
		return $result;
	}

	public function jumlah_penyakit()
	{
		$result = $this->db->get('penyakit')->result_array();

		return $result;
	}

	public function cek_penyakit($kode_diagnosa, $i)
	{
		$penyakit = $this->db->get('penyakit')->result_array();
		$diagnosa = $this->db->get_where('diagnosa', ['kode_diagnosa' => $kode_diagnosa])->last_row();
		$diagnosa_detail = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $kode_diagnosa, 'kode_penyakit' => $penyakit[$i]['kode_penyakit']))->row_array();
		
		return $diagnosa_detail;
	}

	public function cek_penyakit2($i)
	{
		$penyakit = $this->db->get('penyakit')->result_array();
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$diagnosa = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		if (isset($diagnosa)) {
			$diagnosa_detail = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $diagnosa->kode_diagnosa, 'kode_penyakit' => $penyakit[$i]['kode_penyakit']))->row_array();
			return $diagnosa_detail;
		}
		
	}

	public function nama_penyakit($request)
	{
		$result = $this->db->get_where('penyakit', ['kode_penyakit' => $request])->row_array();
		return $result;
	}

	public function penyakit_ginjal()
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$diagnosa = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		if (isset($diagnosa)) {
			$penyakit1 = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $diagnosa->kode_diagnosa, 'kode_penyakit' => 'P0_1'))->row_array();
		return $penyakit1;
		}

	}

	public function penyakit_tipes()
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$diagnosa = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		if (isset($diagnosa)) {
			$penyakit1 = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $diagnosa->kode_diagnosa, 'kode_penyakit' => 'P0_2'))->row_array();
		return $penyakit1;
		}

	}

	public function gejala($request)
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$diagnosa = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		if (isset($diagnosa)) {
			$gejala = $this->db->get_where('gejala_return', ['kode_penyakit' => $request])->result_array();

			return $gejala;
		}
	}


	public function ambil_gejala($kode_penyakit, $i)
	{
		$auth = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$diagnosa = $this->db->get_where('diagnosa', ['email' => $auth['email']])->last_row();
		$gejala = $this->db->get_where('gejala_return', ['kode_penyakit' => $kode_penyakit])->result_array();
		$return = $this->db->get_where('gejala_return', ['id_gejala_return' => $gejala[$i]['id_gejala_return']])->row_array();

		return $return;
	}

	public function view_gejala($kode_diagnosa, $kode_penyakit)
	{
		$gejala = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $kode_diagnosa, 'kode_penyakit' => $kode_penyakit))->result_array();

		return $gejala;
	}

	public function view_ambil_gejala($kode_diagnosa, $kode_penyakit, $i)
	{
		$detail = $this->db->get_where('diagnosa_detail', array('kode_diagnosa' => $kode_diagnosa, 'kode_penyakit' => $kode_penyakit))->result_array();
		$gejala = $this->db->get_where('gejala', ['kode_gejala' => $detail[$i]['kode_gejala']])->row_array();

		return $gejala;
	}

	public function solusi($request)
	{
		$solusi = $this->db->get_where('solusi', ['kode_penyakit' => $request])->result_array();

		return $solusi;
	}

	public function ambil_referensi($request)
	{
		$referensi = $this->db->get_where('penyakit', ['kode_penyakit' => $request])->row_array();

		return $referensi;
	}

	public function data_diagnosa($kode_diagnosa)
	{
		$result = $this->db->get_where('diagnosa', ['kode_diagnosa' => $kode_diagnosa ])->row_array();

		return $result;
	}


	
}