const flashdata = $('.flash-data').data('flashdata');

if (flashdata) {
	Swal({
		title: 'Berhasil',
		text: flashdata,
		type: 'success',
	});
}